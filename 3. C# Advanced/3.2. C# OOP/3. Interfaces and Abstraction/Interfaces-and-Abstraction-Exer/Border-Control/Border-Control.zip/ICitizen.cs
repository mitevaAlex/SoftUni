﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Border_Control
{
    public interface ICitizen
    {
        string Id { get; }
    }
}
