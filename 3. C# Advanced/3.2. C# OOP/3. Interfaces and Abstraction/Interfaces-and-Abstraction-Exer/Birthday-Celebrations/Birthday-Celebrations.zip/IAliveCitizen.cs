﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Birthday_Celebrations
{
    public interface IAliveCitizen
    {
        string Name { get; }

        string Birthdate { get; }

    }
}
