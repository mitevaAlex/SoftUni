﻿namespace Military_Elite
{
    public interface ISoldier
    {
        string FirstName { get; }

        string Id { get; }

        string LastName { get; }
    }
}