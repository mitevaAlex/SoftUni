﻿namespace Military_Elite
{
    public interface IPrivate
    {
        decimal Salary { get; }
    }
}