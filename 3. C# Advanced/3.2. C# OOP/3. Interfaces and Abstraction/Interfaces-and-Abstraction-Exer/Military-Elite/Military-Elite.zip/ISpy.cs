﻿namespace Military_Elite
{
    public interface ISpy
    {
        int CodeNumber { get; }
    }
}