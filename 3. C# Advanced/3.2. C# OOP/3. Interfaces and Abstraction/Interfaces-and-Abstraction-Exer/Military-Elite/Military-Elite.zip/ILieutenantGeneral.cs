﻿using System.Collections.Generic;

namespace Military_Elite
{
    public interface ILieutenantGeneral
    {
        List<Private> Privates { get; }
    }
}