﻿namespace Military_Elite
{
    public interface IRepair
    {
        int HoursWorked { get; }
        string PartName { get; }
    }
}