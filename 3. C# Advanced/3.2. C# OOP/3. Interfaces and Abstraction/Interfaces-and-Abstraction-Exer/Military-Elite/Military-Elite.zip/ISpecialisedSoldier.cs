﻿using System.Collections.Generic;

namespace Military_Elite
{
    public interface ISpecialisedSoldier
    {
        string Corps { get; }
    }
}