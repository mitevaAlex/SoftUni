﻿using System;

namespace Vehicles
{
    class Program
    {
        static void Main()
        {
            string[] carInfo = Console.ReadLine()
                .Split(' ');
            Car car = new Car(double.Parse(carInfo[1]), double.Parse(carInfo[2]), double.Parse(carInfo[3]));
            string[] truckInfo = Console.ReadLine()
                .Split(' ');
            Truck truck = new Truck(double.Parse(truckInfo[1]), double.Parse(truckInfo[2]), double.Parse(truckInfo[3]));
            string[] busInfo = Console.ReadLine()
                .Split(' ');
            Bus bus = new Bus(double.Parse(busInfo[1]), double.Parse(busInfo[2]), double.Parse(busInfo[3]));
            int commandsCount = int.Parse(Console.ReadLine());
            for (int i = 0; i < commandsCount; i++)
            {
                string[] args = Console.ReadLine()
                    .Split(' ');
                string action = args[0];
                string vehicle = args[1];
                double kmOrLiters = double.Parse(args[2]);
                switch (action)
                {
                    case "Drive":
                        if (vehicle == "Car")
                        {
                            car.Drive(kmOrLiters);
                        }
                        else if (vehicle == "Truck")
                        {
                            truck.Drive(kmOrLiters);
                        }
                        else if (vehicle == "Bus")
                        {
                            bus.Drive(kmOrLiters, "full");
                        }
                        break;
                    case "DriveEmpty":
                        bus.Drive(kmOrLiters, "empty");
                        break;
                    case "Refuel":
                        if (vehicle == "Car")
                        {
                            car.Refuel(kmOrLiters);
                        }
                        else if (vehicle == "Truck")
                        {
                            truck.Refuel(kmOrLiters);
                        }
                        else if (vehicle == "Bus")
                        {
                            bus.Refuel(kmOrLiters);
                        }
                        break;
                }
            }

            Console.WriteLine(car);
            Console.WriteLine(truck);
            Console.WriteLine(bus);
        }
    }
}
