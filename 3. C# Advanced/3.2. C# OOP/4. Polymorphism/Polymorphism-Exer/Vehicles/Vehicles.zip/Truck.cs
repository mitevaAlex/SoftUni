﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Vehicles 
{
    public class Truck : IVehicle
    {
        private const double AirConditionerConsumption = 1.6;
        private const double KeptFuelPercent = 0.95;

        public Truck(double fuelQuantity, double fuelConsumption)
        {
            this.FuelQuantity = fuelQuantity;
            this.FuelConsumptionaPerKm = fuelConsumption;
        }

        public double FuelQuantity { get; private set; }

        public double FuelConsumptionaPerKm { get; private set; }

        public void Drive(double km)
        {
            double fuelNeeded = km * (AirConditionerConsumption + this.FuelConsumptionaPerKm);
            if (fuelNeeded <= this.FuelQuantity)
            {
                this.FuelQuantity -= fuelNeeded;
                Console.WriteLine($"Truck travelled {km} km");
            }
            else
            {
                Console.WriteLine("Truck needs refueling");
            }
        }

        public void Refuel(double fuelAmount)
        {
            this.FuelQuantity += fuelAmount * KeptFuelPercent;
        }

        public override string ToString()
        {
            return $"Truck: {this.FuelQuantity:F2}";
        }
    }
}
