﻿using System;

namespace Vehicles
{
    class Program
    {
        static void Main()
        {
            string[] carInfo = Console.ReadLine()
                .Split(' ');
            Car car = new Car(double.Parse(carInfo[1]), double.Parse(carInfo[2]));
            string[] truckInfo = Console.ReadLine()
                .Split(' ');
            Truck truck = new Truck(double.Parse(truckInfo[1]), double.Parse(truckInfo[2]));
            int commandsCount = int.Parse(Console.ReadLine());
            for (int i = 0; i < commandsCount; i++)
            {
                string[] args = Console.ReadLine()
                    .Split(' ');
                string action = args[0];
                string vehicle = args[1];
                double kmOrLiters = double.Parse(args[2]);
                switch (action)
                {
                    case "Drive":
                        if (vehicle == "Car")
                        {
                            car.Drive(kmOrLiters);
                        }
                        else if (vehicle == "Truck")
                        {
                            truck.Drive(kmOrLiters);
                        }
                        break;
                    case "Refuel":
                        if (vehicle == "Car")
                        {
                            car.Refuel(kmOrLiters);
                        }
                        else if (vehicle == "Truck")
                        {
                            truck.Refuel(kmOrLiters);
                        }
                        break;
                }
            }

            Console.WriteLine(car);
            Console.WriteLine(truck);
        }
    }
}
