﻿using NUnit.Framework;

[TestFixture]
public class DummyTests
{
    [Test]
    public void DummyLosesHealthIfAttacked()
    {
        Dummy dummy = new Dummy(10, 10);

        dummy.TakeAttack(1);

        Assert.That(dummy.Health, Is.EqualTo(9));
    }

    [Test]
    public void DeadDummyThrowsExceptionIfAttacked()
    {
        Dummy dummy = new Dummy(-10, 10);

        Assert.That(() => dummy.TakeAttack(10),
            Throws.InvalidOperationException.With.Message.EqualTo("Dummy is dead."));
    }

    [Test]
    public void DeadDummyGivesXP()
    {
        Dummy dummy = new Dummy(-10, 1);

        Assert.That(() => dummy.GiveExperience(), Is.EqualTo(1));
    }

    [Test]
    public void AliveDummyDoesntGiveXP()
    {
        Dummy dummy = new Dummy(100, 1);

        Assert.That(() => dummy.GiveExperience(),
            Throws.InvalidOperationException.With.Message.EqualTo("Target is not dead."));
    }

}
