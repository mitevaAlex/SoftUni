﻿using NUnit.Framework;

[TestFixture]
public class HeroTests
{
    [Test]
    public void HeroGainsXPWhenTargetDies()
    {
        IWeapon fakeWeapon = new Axe(10, 10);
        ITarget fakeTarget = new Dummy(5, 10);
        Hero hero = new Hero("Alex", fakeWeapon);

        hero.Attack(fakeTarget);

        Assert.That(hero.Experience, Is.EqualTo(10));
    }
}