﻿using System;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _01.EvenLines
{
    class Program
    {
        static async Task Main(string[] args)
        {
            char[] charsToReplace =
            { 
                '-',
                ',',
                '.',
                '!',
                '?'
            };

            using (StreamReader reader = new StreamReader("input.txt"))
            {
                int lineNumber = 0;
                string line = await reader.ReadLineAsync();

                while (line != null)
                {
                    if (lineNumber % 2 == 0)
                    {
                       line =  ReplaceAll(charsToReplace, '@', line);
                       line = Reversing(line);
                        Console.WriteLine(line);
                    }

                    lineNumber++;
                    line = await reader.ReadLineAsync();
                }
            }
        }

         static string Reversing(string line)
        {
            StringBuilder builder = new StringBuilder();

            string[] word = line.Split(" ", StringSplitOptions.RemoveEmptyEntries)
                .ToArray();

            for (int i = 0; i < word.Length; i++)
            {
                builder.Append(word[word.Length-i-1]);
                builder.Append(' ');
            }

            return builder.ToString().TrimEnd();
        }

        static string ReplaceAll(char[] charsToReplace, char v, string line)
        {
            StringBuilder builder = new StringBuilder();

            for (int i = 0; i < line.Length; i++)
            {
                char symbol = line[i];

                if (charsToReplace.Contains(symbol))
                {
                    builder.Append('@');
                }
                else
                {
                    builder.Append(symbol);
                }
            }

            return builder.ToString()
                .TrimEnd();
        }
    }
}

