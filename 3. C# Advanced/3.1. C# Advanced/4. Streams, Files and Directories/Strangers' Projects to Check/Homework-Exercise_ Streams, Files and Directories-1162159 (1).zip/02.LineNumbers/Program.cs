﻿using System;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace _02.LineNumbers
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] lines = File.ReadAllLines("input.txt");

            for (int i = 0; i < lines.Length; i++)
            {
                string current = lines[i];
                int letterCounter = LetterCounter(current);
                int marksCounter = MarksCounter(current);

                lines[i] = $"Line {i+1}: {current} ({letterCounter})({marksCounter})";
            }
            File.WriteAllLines("output.txt",lines);
        }

        private static int MarksCounter(string current)
        {
            char[] marks =
            {
                '.',
                ',',
                '?',
                '!',
                '-',
                '\''
            };

            int count = 0;

            for (int i = 0; i < current.Length; i++)
            {
                char currentChar = current[i];
                if (marks.Contains(currentChar))
                {
                    count++;
                }
            }
            return count;
        }

        private static int LetterCounter(string current)
        {
            int count = 0;

            for (int i = 0; i < current.Length; i++)
            {
                char currentChar = current[i];

                if (char.IsLetter(currentChar))
                {
                    count++;
                }
            }
            return count;
        }
    }
}
