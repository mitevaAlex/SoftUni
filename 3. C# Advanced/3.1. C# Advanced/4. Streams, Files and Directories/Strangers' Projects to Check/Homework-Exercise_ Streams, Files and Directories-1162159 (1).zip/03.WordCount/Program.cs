﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace _03.WordCount
{
    class Program
    {
        static void Main(string[] args)
        {
            Dictionary<string, int> matchingWords = new Dictionary<string, int>();

            using (StreamReader reader = new StreamReader("words.txt"))
            {
                string line = reader.ReadLine();

                while (line!=null)
                {
                    string word = line.Split(" ", StringSplitOptions.RemoveEmptyEntries)
                        .ToArray()[0]
                        .ToLower();

                    if (!matchingWords.ContainsKey(word))
                    {
                        matchingWords[word] = 0;
                    }
                    line = reader.ReadLine();
                }
            }

            using (StreamWriter writer = new StreamWriter("result.txt"))
            {
                using(StreamReader reader = new StreamReader("lines.txt"))
                {
                    string lines = reader.ReadLine();

                    while (lines!=null)
                    {
                        string[] words = lines.Split(" ", StringSplitOptions.RemoveEmptyEntries)
                            .Select(x => x.Trim(new char[]
                            {
                                '-',
                                ',',
                                '.',
                                '!',
                                '?'
                            }))
                            .Select(x => x.ToLower())
                            .ToArray();

                        foreach (string word in words)
                        {
                            if (matchingWords.ContainsKey(word))
                            {
                                matchingWords[word]++; 
                            }
                        }
                        lines = reader.ReadLine();
                    }
                    foreach (KeyValuePair<string,int> kvp in matchingWords.OrderByDescending(x=>x.Value))
                    {
                        writer.WriteLine($"{kvp.Key} - {kvp.Value}");
                    }
                }
            }
        }
    }
}
4