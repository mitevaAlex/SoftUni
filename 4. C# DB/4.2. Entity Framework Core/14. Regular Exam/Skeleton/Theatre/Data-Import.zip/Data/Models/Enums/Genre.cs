﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Theatre.Data.Models.Enums
{
    public enum Genre
    {
        Drama = 0, 
        Comedy = 1, 
        Romance = 2, 
        Musical = 3
    }
}
