﻿namespace Theatre.DataProcessor.ExportDto
{
    public class ExportTicketDto
    {
        public decimal Price { get; set; }

        public sbyte RowNumber { get; set; }
    }
}