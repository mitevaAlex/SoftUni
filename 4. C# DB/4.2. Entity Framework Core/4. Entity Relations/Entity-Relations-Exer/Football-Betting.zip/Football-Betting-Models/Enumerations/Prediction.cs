﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P03_FootballBetting.Data.Models.Enumerations
{
    public enum Prediction
    {
        Draw,
        Home,
        Away
    }
}
