﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using AutoMapper;
using CarDealer.Data;
using CarDealer.DTO;
using CarDealer.Models;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json;

namespace CarDealer
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            CarDealerContext context = new CarDealerContext();
            //context.Database.EnsureDeleted();
            //context.Database.EnsureCreated();

            //string suppliersJson = File.ReadAllText("Datasets\\suppliers.json");
            //Console.WriteLine(ImportSuppliers(context, suppliersJson));

            //string partsJson = File.ReadAllText("Datasets\\parts.json");
            //Console.WriteLine(ImportParts(context, partsJson));

            //string carsJson = File.ReadAllText("Datasets\\cars.json");
            //Console.WriteLine(ImportCars(context, carsJson));

            string customersJson = File.ReadAllText("Datasets\\customers.json");
            Console.WriteLine(ImportCustomers(context, customersJson));
        }

        public static string ImportSuppliers(CarDealerContext context, string inputJson)
        {
            IEnumerable<Supplier> suppliers = JsonConvert.DeserializeObject<IEnumerable<Supplier>>(inputJson);
            context.Suppliers.AddRange(suppliers);
            context.SaveChanges();
            return $"Successfully imported {context.Suppliers.Count()}.";
        }

        public static string ImportParts(CarDealerContext context, string inputJson)
        {
            IEnumerable<Part> parts = JsonConvert.DeserializeObject<IEnumerable<Part>>(inputJson)
                .Where(x => context.Suppliers.FirstOrDefault(y => y.Id == x.SupplierId) != null);
            context.Parts.AddRange(parts);
            context.SaveChanges();
            return $"Successfully imported {context.Parts.Count()}.";
        }

        public static string ImportCars(CarDealerContext context, string inputJson)
        {

            IEnumerable<CarDTO> carsDTO = JsonConvert.DeserializeObject<IEnumerable<CarDTO>>(inputJson);

            foreach (var carDTO in carsDTO)
            {
                Car car = new Car
                {
                    Make = carDTO.Make,
                    Model = carDTO.Model,
                    TravelledDistance = carDTO.TravelledDistance
                };

                context.Cars.Add(car);

                foreach (var partId in carDTO.PartsId)
                {
                    PartCar partCar = new PartCar
                    {
                        CarId = car.Id,
                        PartId = partId
                    };

                    if (car.PartCars.FirstOrDefault(p => p.PartId == partId) == null)
                    {
                        context.PartCars.Add(partCar);
                    }
                }
            }

            context.SaveChanges();
            return $"Successfully imported {context.Cars.Count()}.";
        }

        public static string ImportCustomers(CarDealerContext context, string inputJson)
        {
            IEnumerable<Customer> customers = JsonConvert.DeserializeObject<IEnumerable<Customer>>(inputJson);
            context.Customers.AddRange(customers);
            context.SaveChanges();
            return $"Successfully imported {context.Customers.Count()}.";
        }
    }
}