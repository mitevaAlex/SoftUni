﻿namespace ProductShop
{
    using System;
    using Data;
    using ProductShop.Models;
    using System.IO;
    using System.Linq;
    using System.Xml.Serialization;
    using ProductShop.DTO.Import;
    using AutoMapper;

    public class StartUp
    {
        public static MapperConfiguration mapConfig = new MapperConfiguration(x => x.AddProfile<ProductShopProfile>());
        public static IMapper mapper = mapConfig.CreateMapper();

        public static void Main(string[] args)
        {
            ProductShopContext context = new ProductShopContext();
            //context.Database.EnsureCreated();

            //string usersXml = new StreamReader("Datasets/users.xml").ReadToEnd();
            //Console.WriteLine(ImportUsers(context, usersXml));

            string productsXml = new StreamReader("Datasets/products.xml").ReadToEnd();
            Console.WriteLine(ImportProducts(context, productsXml));
        }

        public static string ImportUsers(ProductShopContext context, string inputXml)
        {
            XmlSerializer serializer = new XmlSerializer(typeof(ImportUserDto[]), new XmlRootAttribute("Users"));
            ImportUserDto[] users = (ImportUserDto[])serializer.Deserialize(new StringReader(inputXml));
            context.Users.AddRange(mapper.Map<User[]>(users));
            context.SaveChanges();

            return $"Successfully imported {context.Users.Count()}";
        }

        public static string ImportProducts(ProductShopContext context, string inputXml)
        {
            XmlSerializer serializer = new XmlSerializer(typeof(ImportProductDto[]), new XmlRootAttribute("Products"));
            ImportProductDto[] products = (ImportProductDto[])serializer.Deserialize(new StringReader(inputXml));
            context.Products.AddRange(mapper.Map<Product[]>(products));
            context.SaveChanges();

            return $"Successfully imported {context.Products.Count()}";
        }
    }
}