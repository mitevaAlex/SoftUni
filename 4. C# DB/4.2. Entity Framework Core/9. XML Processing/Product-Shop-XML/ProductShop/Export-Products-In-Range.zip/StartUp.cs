﻿namespace ProductShop
{
    using System;
    using Data;
    using ProductShop.Models;
    using System.IO;
    using System.Linq;
    using System.Xml.Serialization;
    using ProductShop.DTO.Import;
    using AutoMapper;
    using AutoMapper.QueryableExtensions;
    using ProductShop.DTO.Export;
    using System.Xml.Linq;
    using System.Xml;
    using System.Text;

    public class StartUp
    {
        public static MapperConfiguration mapConfig = new MapperConfiguration(x => x.AddProfile<ProductShopProfile>());
        public static IMapper mapper = mapConfig.CreateMapper();

        public static void Main(string[] args)
        {
            ProductShopContext context = new ProductShopContext();
            //context.Database.EnsureCreated();

            //string usersXml = new StreamReader("Datasets/users.xml").ReadToEnd();
            //Console.WriteLine(ImportUsers(context, usersXml));

            //string productsXml = new StreamReader("Datasets/products.xml").ReadToEnd();
            //Console.WriteLine(ImportProducts(context, productsXml));

            //string categoriesXml = new StreamReader("Datasets/categories.xml").ReadToEnd();
            //Console.WriteLine(ImportCategories(context, categoriesXml));

            //string categoriesProductsXml = new StreamReader("Datasets/categories-products.xml").ReadToEnd();
            //Console.WriteLine(ImportCategoryProducts(context, categoriesProductsXml));

            Console.WriteLine(GetProductsInRange(context));
        }

        public static string ImportUsers(ProductShopContext context, string inputXml)
        {
            XmlSerializer serializer = new XmlSerializer(typeof(ImportUserDto[]), new XmlRootAttribute("Users"));
            ImportUserDto[] users = (ImportUserDto[])serializer.Deserialize(new StringReader(inputXml));
            context.Users.AddRange(mapper.Map<User[]>(users));
            context.SaveChanges();

            return $"Successfully imported {context.Users.Count()}";
        }

        public static string ImportProducts(ProductShopContext context, string inputXml)
        {
            XmlSerializer serializer = new XmlSerializer(typeof(ImportProductDto[]), new XmlRootAttribute("Products"));
            ImportProductDto[] products = (ImportProductDto[])serializer.Deserialize(new StringReader(inputXml));
            context.Products.AddRange(mapper.Map<Product[]>(products));
            context.SaveChanges();

            return $"Successfully imported {context.Products.Count()}";
        }

        public static string ImportCategories(ProductShopContext context, string inputXml)
        {
            XmlSerializer serializer = new XmlSerializer(typeof(ImportCategoryDto[]), new XmlRootAttribute("Categories"));
            ImportCategoryDto[] categories = (ImportCategoryDto[])serializer.Deserialize(new StringReader(inputXml));
            context.Categories.AddRange(mapper.Map<Category[]>(categories));
            context.SaveChanges();

            return $"Successfully imported {context.Categories.Count()}";
        }

        public static string ImportCategoryProducts(ProductShopContext context, string inputXml)
        {
            XmlSerializer serializer = new XmlSerializer(typeof(ImportCategoryProductDto[]), new XmlRootAttribute("CategoryProducts"));
            ImportCategoryProductDto[] categoriesProducts = (ImportCategoryProductDto[])serializer
                .Deserialize(new StringReader(inputXml));
            categoriesProducts = categoriesProducts
                .Where(x =>
                context.Categories.FirstOrDefault(y => y.Id == x.CategoryId) != null
                && context.Products.FirstOrDefault(y => y.Id == x.ProductId) != null)
                .ToArray();
            context.CategoryProducts.AddRange(mapper.Map<CategoryProduct[]>(categoriesProducts));
            context.SaveChanges();

            return $"Successfully imported {context.CategoryProducts.Count()}";
        }

        public static string GetProductsInRange(ProductShopContext context)
        {
            ExportProductPriceBuyerDto[] products = context.Products
                .Where(x => x.Price >= 500 && x.Price <= 1000)
                .ProjectTo<ExportProductPriceBuyerDto>(mapConfig)
                .OrderBy(x => x.Price)
                .Take(10)
                .ToArray();

            XmlSerializer serializer = new XmlSerializer(typeof(ExportProductPriceBuyerDto[]), new XmlRootAttribute("Products"));
            XmlSerializerNamespaces namespaces = new XmlSerializerNamespaces();
            namespaces.Add(string.Empty, string.Empty);

            StringBuilder sb = new StringBuilder();
            using (StringWriter sw = new StringWriter(sb))
            {
                serializer.Serialize(sw, products, namespaces);
            }

            using (StreamWriter sw = new StreamWriter("products-in-range.xml"))
            {
                sw.Write(sb.ToString().Trim());
            }

            return sb.ToString().Trim();
        }
    }
}