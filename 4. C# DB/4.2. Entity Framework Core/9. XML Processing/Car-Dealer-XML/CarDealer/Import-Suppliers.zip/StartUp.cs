﻿using System;
using CarDealer.Data;
using System.IO;
using System.Xml.Serialization;
using AutoMapper;
using CarDealer.DTO.Import;
using CarDealer.Models;
using System.Linq;

namespace CarDealer
{
    public class StartUp
    {
        public static MapperConfiguration mapConfig = new MapperConfiguration(x => x.AddProfile<CarDealerProfile>());
        public static IMapper mapper = mapConfig.CreateMapper();

        public static void Main(string[] args)
        {
            CarDealerContext context = new CarDealerContext();
            //context.Database.EnsureCreated();

            string suppliersXml = new StreamReader("Datasets/suppliers.xml").ReadToEnd();
            Console.WriteLine(ImportSuppliers(context, suppliersXml));
        }

        public static string ImportSuppliers(CarDealerContext context, string inputXml)
        {
            XmlSerializer serializer = new XmlSerializer(typeof(ImportSupplierDto[]), new XmlRootAttribute("Suppliers"));
            ImportSupplierDto[] suppliers = (ImportSupplierDto[])serializer.Deserialize(new StringReader(inputXml));
            context.Suppliers.AddRange(mapper.Map<Supplier[]>(suppliers));
            context.SaveChanges();

            return $"Successfully imported {context.Suppliers.Count()}";
        }
    }
}