﻿using AutoMapper;
using CarDealer.DTO.Import;
using CarDealer.Models;

namespace CarDealer
{
    public class CarDealerProfile : Profile
    {
        public CarDealerProfile()
        {
            this.CreateMap<ImportSupplierDto, Supplier>();

            //this.CreateMap<Product, ExportProductPriceBuyerDto>()
            //   .ForMember(dto => dto.BuyerName,
            //   opt => opt.MapFrom(src => src.Buyer.FirstName + " " + src.Buyer.LastName))
            //   .ForMember(dto => dto.Price,
            //   opt => opt.MapFrom(src => src.Price.ToString().Trim('0')));
        }
    }
}
