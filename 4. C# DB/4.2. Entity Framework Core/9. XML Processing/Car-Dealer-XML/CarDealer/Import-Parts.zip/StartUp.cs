﻿using System;
using CarDealer.Data;
using System.IO;
using System.Xml.Serialization;
using AutoMapper;
using CarDealer.DTO.Import;
using CarDealer.Models;
using System.Linq;

namespace CarDealer
{
    public class StartUp
    {
        public static MapperConfiguration mapConfig = new MapperConfiguration(x => x.AddProfile<CarDealerProfile>());
        public static IMapper mapper = mapConfig.CreateMapper();

        public static void Main(string[] args)
        {
            CarDealerContext context = new CarDealerContext();
            //context.Database.EnsureCreated();

            //string suppliersXml = new StreamReader("Datasets/suppliers.xml").ReadToEnd();
            //Console.WriteLine(ImportSuppliers(context, suppliersXml));

            string partsXml = new StreamReader("Datasets/parts.xml").ReadToEnd();
            Console.WriteLine(ImportParts(context, partsXml));
        }

        public static string ImportSuppliers(CarDealerContext context, string inputXml)
        {
            XmlSerializer serializer = new XmlSerializer(typeof(ImportSupplierDto[]), new XmlRootAttribute("Suppliers"));
            ImportSupplierDto[] suppliers = (ImportSupplierDto[])serializer.Deserialize(new StringReader(inputXml));
            context.Suppliers.AddRange(mapper.Map<Supplier[]>(suppliers));
            context.SaveChanges();

            return $"Successfully imported {context.Suppliers.Count()}";
        }

        public static string ImportParts(CarDealerContext context, string inputXml)
        {
            XmlSerializer serializer = new XmlSerializer(typeof(ImportPartDto[]), new XmlRootAttribute("Parts"));
            ImportPartDto[] parts = (ImportPartDto[])serializer.Deserialize(new StringReader(inputXml));
            parts = parts
                .Where(x => context.Suppliers.FirstOrDefault(y => y.Id == x.SupplierId) != null)
                .ToArray();
            context.Parts.AddRange(mapper.Map<Part[]>(parts));
            context.SaveChanges();

            return $"Successfully imported {context.Parts.Count()}";
        }
    }
}