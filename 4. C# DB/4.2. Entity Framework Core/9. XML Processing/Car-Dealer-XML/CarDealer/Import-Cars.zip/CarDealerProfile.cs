﻿using AutoMapper;
using CarDealer.DTO.Import;
using CarDealer.Models;
using System.Linq;

namespace CarDealer
{
    public class CarDealerProfile : Profile
    {
        public CarDealerProfile()
        {
            this.CreateMap<ImportSupplierDto, Supplier>();

            this.CreateMap<ImportPartDto, Part>();

            this.CreateMap<ImportCarDto, Car>()
                .ForMember(dto => dto.PartCars,
                opt => opt.MapFrom(src => src.Parts.Select(x => new PartCar() { PartId = x.Id })));



            //this.CreateMap<Product, ExportProductPriceBuyerDto>()
            //   .ForMember(dto => dto.BuyerName,
            //   opt => opt.MapFrom(src => src.Buyer.FirstName + " " + src.Buyer.LastName))
            //   .ForMember(dto => dto.Price,
            //   opt => opt.MapFrom(src => src.Price.ToString().Trim('0')));
        }
    }
}
