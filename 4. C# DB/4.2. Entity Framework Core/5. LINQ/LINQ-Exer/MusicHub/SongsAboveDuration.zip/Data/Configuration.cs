﻿namespace MusicHub.Data
{
   public static class Configuration
    {
        public static string ConnectionString =
            @"Server=DESKTOP-NQ0DDAV\SQLEXPRESS;Database=MusicHub;Trusted_Connection=True";
    }
}
