﻿namespace BookShop
{
    using Data;
    using Initializer;
    using System;
    using System.Linq;

    public class StartUp
    {
        public static void Main()
        {
            using var db = new BookShopContext();
            //DbInitializer.ResetDatabase(db);

            //string command = Console.ReadLine();
            //Console.WriteLine(GetBooksByAgeRestriction(db, command));

            Console.WriteLine(GetGoldenBooks(db));
        }

        public static string GetBooksByAgeRestriction(BookShopContext context, string command)
        {
            command = command.ToUpper();

            var books = context.Books
                .ToArray()
                .Where(x => x.AgeRestriction.ToString().ToUpper() == command)
                .Select(x => x.Title)
                .OrderBy(x => x);

            return string.Join(Environment.NewLine, books);
        }

        public static string GetGoldenBooks(BookShopContext context)
        {
            var books = context.Books
                .ToArray()
                .Where(x => x.EditionType.ToString() == "Gold" && x.Copies < 5000)
                .OrderBy(x => x.BookId)
                .Select(x => x.Title);
            return string.Join(Environment.NewLine, books);
        }
    }
}
