﻿namespace BookShop
{
    using Data;
    using Initializer;
    using System;
    using System.Collections.Generic;
    using System.Globalization;
    using System.Linq;
    using System.Text;

    public class StartUp
    {
        public static void Main()
        {
            using var db = new BookShopContext();
            //DbInitializer.ResetDatabase(db);

            //string command = Console.ReadLine();
            //Console.WriteLine(GetBooksByAgeRestriction(db, command));

            //Console.WriteLine(GetGoldenBooks(db));

            //Console.WriteLine(GetBooksByPrice(db));

            //int year = int.Parse(Console.ReadLine());
            //Console.WriteLine(GetBooksNotReleasedIn(db, year));

            //string categoriesString = Console.ReadLine();
            //Console.WriteLine(GetBooksByCategory(db, categoriesString));

            //string date = Console.ReadLine();
            //Console.WriteLine(GetBooksReleasedBefore(db, date));

            //string firstNameEnd = Console.ReadLine();
            //Console.WriteLine(GetAuthorNamesEndingIn(db, firstNameEnd));

            string input = Console.ReadLine();
            Console.WriteLine(GetBookTitlesContaining(db, input));
        }

        public static string GetBooksByAgeRestriction(BookShopContext context, string command)
        {
            command = command.ToUpper();

            var books = context.Books
                .ToArray()
                .Where(x => x.AgeRestriction.ToString().ToUpper() == command)
                .Select(x => x.Title)
                .OrderBy(x => x);

            return string.Join(Environment.NewLine, books);
        }

        public static string GetGoldenBooks(BookShopContext context)
        {
            var books = context.Books
                .ToArray()
                .Where(x => x.EditionType.ToString() == "Gold" && x.Copies < 5000)
                .OrderBy(x => x.BookId)
                .Select(x => x.Title);
            return string.Join(Environment.NewLine, books);
        }

        public static string GetBooksByPrice(BookShopContext context)
        {
            var books = context.Books
                .Where(x => x.Price > 40)
                .Select(x => new { Title = x.Title, Price = x.Price })
                .OrderByDescending(x => x.Price);
            return string.Join(Environment.NewLine, books.Select(x => $"{x.Title} - ${x.Price:F2}"));
        }

        public static string GetBooksNotReleasedIn(BookShopContext context, int year)
        {
            var books = context.Books
                .ToArray()
               .Where(x => DateTime.Parse(x.ReleaseDate.ToString()).Year != year)
               .OrderBy(x => x.BookId)
               .Select(x => x.Title);
            return string.Join(Environment.NewLine, books);
        }

        public static string GetBooksByCategory(BookShopContext context, string input)
        {
            string[] categories = input
                .Split(' ', StringSplitOptions.RemoveEmptyEntries)
                .Select(x => x.ToUpper())
                .ToArray();

            List<string> books = new List<string>();
            foreach (string category in categories)
            {
                var currentBooks = context.Books
                    .Where(x => x.BookCategories.Select(y => y.Category.Name.ToUpper()).Contains(category))
                    .Select(x => x.Title);
                books.AddRange(currentBooks);
            }

            books = books
                .OrderBy(x => x)
                .ToList();

            return string.Join(Environment.NewLine, books);
        }

        public static string GetBooksReleasedBefore(BookShopContext context, string date)
        {
            DateTime convertedDate = DateTime.ParseExact(date, "dd-MM-yyyy", CultureInfo.InvariantCulture);
            var books = context.Books
                .Where(x => x.ReleaseDate < convertedDate)
                .OrderByDescending(x => x.ReleaseDate)
                .Select(x => new
                {
                    Title = x.Title,
                    EditionType = x.EditionType,
                    Price = x.Price.ToString("F2")
                });

            return string.Join(Environment.NewLine, books.Select(x => $"{x.Title} - {x.EditionType} - ${x.Price}"));
        }

        public static string GetAuthorNamesEndingIn(BookShopContext context, string input)
        {
            var authors = context.Authors
                .ToArray()
                .Where(x => x.FirstName.EndsWith(input))
                .Select(x => $"{x.FirstName} {x.LastName}")
                .OrderBy(x => x);

            return string.Join(Environment.NewLine, authors);
        }

        public static string GetBookTitlesContaining(BookShopContext context, string input)
        {
            input = input.ToUpper();
            var books = context.Books
                .Where(x => x.Title.ToUpper().Contains(input))
                .Select(x => x.Title)
                .OrderBy(x => x);

            return string.Join(Environment.NewLine, books);
        }
    }
}
