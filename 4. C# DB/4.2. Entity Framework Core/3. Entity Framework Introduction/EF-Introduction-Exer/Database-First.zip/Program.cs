﻿using System;

namespace SoftUni
{
    class Program
    {
        static void Main(string[] args)
        {
        }
    }
}
