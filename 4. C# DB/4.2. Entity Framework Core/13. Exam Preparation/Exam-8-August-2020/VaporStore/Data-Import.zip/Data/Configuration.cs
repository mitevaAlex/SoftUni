﻿namespace VaporStore.Data
{
	public static class Configuration
	{
		public static string ConnectionString =
			@"Server=DESKTOP-NQ0DDAV\SQLEXPRESS;Database=VaporStore;Trusted_Connection=True";
	}
}